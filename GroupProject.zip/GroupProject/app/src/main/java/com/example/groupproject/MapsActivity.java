package com.example.groupproject;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.groupproject.databinding.ActivityMapsBinding;

import java.util.Vector;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    MarkerOptions marker;
    LatLng centerlocation;

    Vector<MarkerOptions> markerOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.dMap);
        mapFragment.getMapAsync(this);

        centerlocation = new LatLng(4.210484, 101.975766);

        markerOptions = new Vector<>();

        markerOptions.add(new MarkerOptions().title("Kedah Medical Centre Sdn. Bhd.")
                .position(new LatLng(6.149034, 100.369585))
                .snippet("Open : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Putra Medical Centre")
                .position(new LatLng(6.123742, 100.365715))
                .snippet("Open : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Sultanah Bahiyah Hospital")
                .position(new LatLng(6.148824, 100.406374))
                .snippet("Open : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Kota Setar District Health Office")
                .position(new LatLng(6.141291, 100.370921))
                .snippet("Open : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Apple Medical Clinic")
                .position(new LatLng(6.100082, 100.364966))
                .snippet("Open : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Simpang Kuala Health Clinic")
                .position(new LatLng(6.096848, 100.361172))
                .snippet("Open : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Kuala Kedah Health Clinic")
                .position(new LatLng(6.098882, 100.301092))
                .snippet("Open during MCO : 8am - 6pm")
        );

        markerOptions.add(new MarkerOptions().title("Klinik Dr Asmah Alor Setar")
                .position(new LatLng(6.089955, 100.363681))
                .snippet("Open during MCO : 8am - 6pm")
        );

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));

        for (MarkerOptions mark : markerOptions) {
            mMap.addMarker(mark);
        }

        enableMyLocation();

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(centerlocation, 8));
    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    @SuppressLint("MissingPermission")
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            return;
        }

        // Request location permission properly
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 200);
    }


}